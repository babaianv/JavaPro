package de.aittr.g_31_2_mapstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G312MapstructApplicationTests {

	@Test
	void contextLoads() {
	}

}
