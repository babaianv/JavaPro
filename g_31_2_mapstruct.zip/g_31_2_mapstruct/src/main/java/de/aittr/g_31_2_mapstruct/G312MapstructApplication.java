package de.aittr.g_31_2_mapstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G312MapstructApplication {

	public static void main(String[] args) {
		SpringApplication.run(G312MapstructApplication.class, args);
	}

}
